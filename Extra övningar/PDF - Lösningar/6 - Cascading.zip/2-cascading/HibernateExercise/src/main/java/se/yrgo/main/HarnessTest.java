package se.yrgo.main;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

import se.yrgo.domain.Author;
import se.yrgo.domain.Book;


import java.util.Set;


public class HarnessTest {


    public static void main(String[] args) {
        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("databaseConfig");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

   /*     //creating author and books (here the hibernate.hbm2ddl.auto shoud set to 'create'
        Author author1 = new Author("Adam Persson");
        em.persist(author1);

        author1.createBooksAndAddToBookCollection("456","My book 1");
        author1.createBooksAndAddToBookCollection("789","My book 2");
        author1.createBooksAndAddToBookCollection("444", "My book 3");

        Set<Book>allBooks = author1.getBookCollection();
        System.out.println(allBooks.size());
*/
        //removing the author so by the remove cascade the books will be deleted too
        Author a1 = em.find(Author.class, 1);
        em.remove(a1);

        tx.commit();
        em.close();

    }
}
