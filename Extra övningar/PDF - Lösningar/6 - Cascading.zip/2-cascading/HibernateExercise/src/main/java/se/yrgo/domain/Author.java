package se.yrgo.domain;

import jakarta.persistence.*;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Author {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int id;
    private String name;
    private String address;
    private int age;

    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.REMOVE})
    @JoinColumn(name="AUTHOR_FK")
    private Set<Book> bookCollection;

    @ManyToMany(mappedBy="authors")
    private Set<Publisher>publishers;

    public Author() {}

    public Author(String name) {
        this.name= name;
        this.bookCollection = new HashSet<Book>();
        this.publishers= new HashSet<Publisher>();
    }

    public String toString() {
        return name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public int getAge() {
        return age;
    }

    public void addBookToBookCollection(Book newBook) {
        this.bookCollection.add(newBook);
    }

    public void createBooksAndAddToBookCollection(String isbn, String title) {
        Book book = new Book(isbn, title);
        this.addBookToBookCollection(book);
    }
    public Set<Book> getBookCollection() {
        Set<Book>unmodifiable=
                Collections.unmodifiableSet(this.bookCollection);
        return unmodifiable;
    }

    public Set<Publisher> getPublishers() {
        Set<Publisher>unmodifiable=
                Collections.unmodifiableSet(this.publishers);
        return unmodifiable;
    }

    public void addPublisherToAuthor(Publisher publisher) {
        this.publishers.add(publisher);
        publisher.addAuthorToPublisher(this);
    }


}
