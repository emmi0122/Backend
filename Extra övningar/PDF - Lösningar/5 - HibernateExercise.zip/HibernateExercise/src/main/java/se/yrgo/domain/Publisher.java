package se.yrgo.domain;

import jakarta.persistence.*;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Publisher {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private int id;
    private String name;
    private String email;
    private String address;

    @ManyToMany
    private Set<Author> authors;

    public Publisher() {}

    public Publisher(String name) {
        this.name= name;
        this.authors=new HashSet<Author>();
    }

    public void addAuthorToPublisher(Author author) {
       this.authors.add(author);
    }

    public String toString() {
        return name;
    }

    public Set<Author> getAuthors() {
        Set<Author>unmodifiable=
              Collections.unmodifiableSet(this.authors);
        return unmodifiable;

    }

}
