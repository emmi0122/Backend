package se.yrgo.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import se.yrgo.domain.Author;
import se.yrgo.domain.Book;
import se.yrgo.domain.Publisher;

import java.util.Set;


public class HarnessTest {
    private static SessionFactory sessionFactory = null;

    public static void main(String[] args) {

        SessionFactory sf = getSessionFactory();
        Session session = sf.openSession();
        Transaction tx = session.beginTransaction();

        Book book1= new Book( "456","My book 4" );
        Book book2= new Book("789","My book 5");
        Book book3= new Book( "444", "My book 6");

        session.save(book1);
        session.save(book2);
        session.save(book3);

        Author author1 = new Author("Adam Persson");
        Author author2 = new Author("Johan Svenson");
        session.save(author1);
        session.save(author2);

        Publisher publisher1 = new Publisher("Dragon");
        Publisher publisher2 = new Publisher("Birds");

        session.save(publisher1);
        session.save(publisher2);

        author1.addPublisherToAuthor(publisher1);
        author1.addPublisherToAuthor(publisher2);

        author2.addPublisherToAuthor(publisher1);
        author2.addPublisherToAuthor(publisher2);

        //publisher1.addAuthorToPublisher(author1);
        //publisher1.addAuthorToPublisher(author2);

        //publisher2.addAuthorToPublisher(author1);
        //publisher2.addAuthorToPublisher(author2);

        author1.addBookToBookCollection(book1);
        author1.addBookToBookCollection(book2);
        author1.addBookToBookCollection(book3);
        author2.addBookToBookCollection(book3);

        Set<Book> books = author1.getBookCollection();
        for(Book book: books) {
            System.out.println(book);
        }



        tx.commit();
        session.close();
    }

    private static SessionFactory getSessionFactory() {
        if(sessionFactory ==null) {
            Configuration configuration = new Configuration();
            configuration.configure();

            sessionFactory = configuration.buildSessionFactory();
        }
        return sessionFactory;
    }
}
