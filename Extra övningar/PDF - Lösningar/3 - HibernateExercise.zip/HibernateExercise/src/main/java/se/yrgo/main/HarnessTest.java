package se.yrgo.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import se.yrgo.domain.Author;
import se.yrgo.domain.Book;


public class HarnessTest {
    private static SessionFactory sessionFactory = null;

    public static void main(String[] args) {

        SessionFactory sf = getSessionFactory();
        Session session = sf.openSession();
        Transaction tx = session.beginTransaction();

        Book book1= new Book( "book 1" );
        Author author1 = new Author("Arthur Bengt");
        book1.allocateAuthor(author1);

       // session.save(book1);
        //session.save(author1);

        //Get the book that we have created in the database. In my case it has id 20 and allocate it to the new book
        Author authorFromDatabase = session.get(Author.class, 27);
        System.out.println (authorFromDatabase);

        //creating a new book
       Book book2= new Book("Book 2");
       book2.allocateAuthor(authorFromDatabase );
       session.save(book2);
       System.out.println (book2);


        tx.commit();
        session.close();
    }

    private static SessionFactory getSessionFactory() {
        if(sessionFactory ==null) {
            Configuration configuration = new Configuration();
            configuration.configure();

            sessionFactory = configuration.buildSessionFactory();
        }
        return sessionFactory;
    }
}
