package se.yrgo.main;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

import se.yrgo.domain.Author;
import se.yrgo.domain.Book;


import java.util.Set;


public class HarnessTest {


    public static void main(String[] args) {
        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("databaseConfig");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        //creating author and books (here the hibernate.hbm2ddl.auto shoud set to 'create'
        Author author1 = new Author("Adam Persson");
        em.persist(author1);

        Book book1= new Book( "456","My book 1" );
        author1.addBookToBookCollection(book1);

        Book book2= new Book("789","My book 2");
        author1.addBookToBookCollection(book2);

        Book book3= new Book( "444", "My book 3");
        author1.addBookToBookCollection(book3);

        em.persist(book1);
        em.persist(book2);
        em.persist(book3);

        Set<Book>allBooks = author1.getBookCollection();
        System.out.println(allBooks.size());


        /*
        //query from the table. Here the hibernate.hbm2ddl.auto should be set to 'update'
        Author author = em.find(Author.class, 1);
        System.out.println(author);

        Set<Book> books = author.getBookCollection();
        for (Book b: books) {
            System.out.println(b);
        }

        Book book =em.find(Book.class, 2);
        System.out.println(book);
        */

        tx.commit();
        em.close();

    }
}
